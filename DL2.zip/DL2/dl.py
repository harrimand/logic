#!/usr/bin/env python3.8

import sys
from qm import *
from logic import *
from km import *
from ttprint import *

impTest = "..1 2 5 7..10 14.."

if len(sys.argv) > 1:
    impStr = sys.argv[1]
else:
    impStr = impTest
if len(sys.argv) > 2:
    dcStr = sys.argv[2]
else:
    dcStr = ""

impList = impStr2impList(impStr)
dc = impStr2impList(dcStr)
# print("\n\t", impList)
print("\n")
# impStr = "1, 5, 7, 11, 13, 15, 19, 21, 25, 27, 31"

ttPrint(impStr)

print("\t", impList, "\n")

if max(impList) > 15:
    impL = [n for n in impList if n < 16]
    impH = [n for n in impList if n > 15]
    KML = karnaughMap(impL, 10, 1)
    KMH = karnaughMap(impH, 10, 1)
    for j, k in zip(KML, KMH):
        print(j, k)
else:
    impL = [n for n in impList if n < 16]
    KML = karnaughMap(impL, 10)
    for k in KML:
        print(k)

print("\n")

USOP = tt2usop(impList)
SSOP = tt2ssop(impList, dc)

printSop(USOP)
print("\n\t" + SSOP)

print("\n")

Vars = getVars(USOP)
for t in SSOP.split(" + "):
    print("\t", t.ljust(6), decImps(v2bterms(t, Vars)))

print("\n")


