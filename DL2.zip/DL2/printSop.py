
def printSop(sop):
    '''Parameters: sop long Sum of Products string containing "+" characters
    Split string at maximum "+" position < 80 so print line lengths are < 80'''
    pli = [i for i, n in enumerate(sop) if n == '+']
    remStr = True
    strBr = [0]
    ppoint = 0
    while(remStr):
       np = max([n for n in pli if n < (ppoint + 80)])
       ppoint = np
       strBr.append(np)
       remStr = (np != pli[-1])

    print('\n')
    for n, i in enumerate(strBr[:-1]):
        print(sop[strBr[n]:strBr[n+1]])
    print(sop[strBr[n+1]:])
    print('\n')

