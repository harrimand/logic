
from qm import *

def ttRow(rowNum, bits, colW, out, outW):
    """Parameters:  Row Number, bit width, column Width, output value, output Width
    Convert rowNum to binary and space bits according to column width.
    Append out bit spaced according to outW.  Include "|" characters for table borders."""
    bstr = bin(rowNum)[2:].zfill(bits)
    row = str(rowNum).rjust(10) + "| "
    for b in bstr:
        row += (b.center(colW, "_"))
    row += "|" + out.center(outW)
    return row

def ttPrint(impStr):

    impList = impStr2impList(impStr)
    bitsize = max(impList).bit_length()
    varList = [chr(n) for n in range(65, 65 + bitsize)]

    varOut = "Out"

    colWidth = max([3] + [max([len(n)+2 for n in varList])])

    headStr = ""

    headStr += " ".rjust(12)

    for c in varList:
        headStr += c.center(colWidth)
    headStr += " " + varOut

#    print(" ".rjust(10), "_" * (colWidth * len(varList)+2 + max(3, len(varOut))))
#    print("|".rjust(11), " " * (colWidth * len(varList)-1), "|")




    if(bitsize < 5):
        print(headStr)
        print(" ".rjust(10), "_" * (colWidth * len(varList)+2 + max(3, len(varOut))))
        print("|".rjust(11), " " * (colWidth * len(varList)-1), "|")
        for n in range(2 ** bitsize):
            print(ttRow(n, bitsize, colWidth, "1" if n in impList else "0", max(3,len(varOut))))
    else:
        print(headStr + " " + headStr)
        print(" ".rjust(10), "_" * (colWidth * len(varList)+2 + max(3, len(varOut))), end='')
        print(" ".rjust(10), "_" * (colWidth * len(varList)+2 + max(3, len(varOut))))
        
        print("|".rjust(11), " " * (colWidth * len(varList)-1), "|", end='')
        print("|".rjust(15), " " * (colWidth * len(varList)-1), "|")

        for n in range(2 ** (bitsize-1)):
            print(ttRow(n, bitsize, colWidth, "1" if n in impList else "0", max(3,len(varOut))), end=" ")
            print(ttRow(n + 16, bitsize, colWidth, "1" if (n+16) in impList else "0", max(3,len(varOut))))


    print("\n\n")





# impStr = "1, 5, 7, 11, 13, 15, 19, 21, 25, 27, 31"

# ttPrint(impStr)
# print("\n\n")

